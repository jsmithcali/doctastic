import React from 'react';
import { BookOpen, Search } from 'lucide-react';
import DevinLogo from '@/components/home/DevinLogo';

export default function Wiki() {
  return (
    <div className="h-full flex flex-col items-center justify-center px-4">
      <div className="w-full max-w-xl text-center">
        <div className="flex justify-center mb-6">
          <div className="w-14 h-14 rounded-2xl bg-card border border-border flex items-center justify-center">
            <BookOpen className="w-6 h-6 text-primary" />
          </div>
        </div>
        <h1 className="text-xl font-semibold text-foreground mb-2">DocTasTic Wiki</h1>
        <p className="text-sm text-muted-foreground mb-8">
          Automatically generated documentation for your codebase
        </p>
        
        <div className="relative max-w-md mx-auto mb-8">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search your codebase documentation..."
            className="w-full bg-card border border-border rounded-xl pl-10 pr-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary/40 transition-colors"
          />
        </div>

        <div className="grid grid-cols-2 gap-3 max-w-md mx-auto">
          {['Architecture Overview', 'API Reference', 'Components', 'Data Models'].map((item) => (
            <div key={item} className="p-4 rounded-xl border border-border bg-card/50 text-left">
              <p className="text-xs font-medium text-foreground">{item}</p>
              <p className="text-[10px] text-muted-foreground mt-1">Auto-generated docs</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}