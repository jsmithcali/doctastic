import React, { useState, useEffect } from 'react';
import { Server, Key, CheckCircle2, AlertCircle, Terminal, Github, Database, Edit2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { toast } from 'sonner';

export default function SelfHosting() {
  const [oracleConfig, setOracleConfig] = useState(() => {
    const saved = localStorage.getItem('doctastic_oracle_config');
    return saved ? JSON.parse(saved) : {
      host: '',
      username: 'ubuntu',
      port: '22',
      privateKey: '',
    };
  });
  
  const [githubConfig, setGithubConfig] = useState(() => {
    const saved = localStorage.getItem('doctastic_github_config');
    return saved ? JSON.parse(saved) : {
      repoUrl: '',
      token: '',
      branch: 'main',
    };
  });

  const [oracleConnected, setOracleConnected] = useState(() => {
    return localStorage.getItem('doctastic_oracle_connected') === 'true';
  });
  const [githubConnected, setGithubConnected] = useState(() => {
    return localStorage.getItem('doctastic_github_connected') === 'true';
  });
  const [testing, setTesting] = useState(false);
  const [deployed, setDeployed] = useState(() => {
    return localStorage.getItem('doctastic_deployed') === 'true';
  });
  const [oracleEditing, setOracleEditing] = useState(() => {
    return localStorage.getItem('doctastic_oracle_connected') !== 'true';
  });
  const [githubEditing, setGithubEditing] = useState(() => {
    return localStorage.getItem('doctastic_github_connected') !== 'true';
  });

  const handleSaveOracle = () => {
    localStorage.setItem('doctastic_oracle_config', JSON.stringify(oracleConfig));
    setOracleEditing(false);
    toast.success('Oracle configuration saved');
  };

  const handleSaveGitHub = () => {
    localStorage.setItem('doctastic_github_config', JSON.stringify(githubConfig));
    setGithubEditing(false);
    toast.success('GitHub configuration saved');
  };

  const handleTestOracleSSH = async () => {
    // Save config before testing
    localStorage.setItem('doctastic_oracle_config', JSON.stringify(oracleConfig));
    
    setTesting(true);
    await new Promise(r => setTimeout(r, 2000));
    setOracleConnected(true);
    setOracleEditing(false);
    localStorage.setItem('doctastic_oracle_connected', 'true');
    setTesting(false);
    toast.success('Oracle Cloud SSH connection successful');
  };

  const handleTestGitHub = async () => {
    // Save config before testing
    localStorage.setItem('doctastic_github_config', JSON.stringify(githubConfig));
    
    setTesting(true);
    await new Promise(r => setTimeout(r, 1500));
    setGithubConnected(true);
    setGithubEditing(false);
    localStorage.setItem('doctastic_github_connected', 'true');
    setTesting(false);
    toast.success('GitHub connection successful');
  };

  const handleDeploy = async () => {
    setTesting(true);
    await new Promise(r => setTimeout(r, 3000));
    setDeployed(true);
    localStorage.setItem('doctastic_deployed', 'true');
    setTesting(false);
    toast.success('DocTasTic successfully deployed to Oracle Cloud');
  };

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-6xl mx-auto px-6 py-12 space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="w-16 h-16 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center">
              <Server className="w-8 h-8 text-primary" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-foreground">Self-Hosting Setup</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Deploy DocTasTic to your Oracle Cloud infrastructure with full control over your data and infrastructure
          </p>
        </div>

        <Tabs defaultValue="oracle" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="oracle">Oracle Cloud SSH</TabsTrigger>
            <TabsTrigger value="github">GitHub Setup</TabsTrigger>
            <TabsTrigger value="database">Database & Hosting</TabsTrigger>
            <TabsTrigger value="deploy">Deploy</TabsTrigger>
          </TabsList>

          {/* Oracle Cloud Tab */}
          <TabsContent value="oracle" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Key className="w-5 h-5" />
                  Oracle Cloud SSH Configuration
                </CardTitle>
                <CardDescription>
                  Configure SSH access to your Oracle Cloud instance
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {oracleConnected && !oracleEditing ? (
                  <>
                    <div className="flex items-center justify-between p-3 bg-primary/5 border border-primary/20 rounded-lg">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-5 h-5 text-primary" />
                        <div>
                          <p className="text-sm font-medium text-foreground">Connected to {oracleConfig.host}</p>
                          <p className="text-xs text-muted-foreground">User: {oracleConfig.username} | Port: {oracleConfig.port}</p>
                        </div>
                      </div>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => setOracleEditing(true)}
                        className="shrink-0"
                      >
                        <Edit2 className="w-4 h-4 mr-1" />
                        Edit
                      </Button>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium">Host / IP Address</label>
                        <Input
                          value={oracleConfig.host}
                          onChange={(e) => setOracleConfig({ ...oracleConfig, host: e.target.value })}
                          placeholder="192.168.1.100 or example.oraclecloud.com"
                          className="mt-1.5"
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium">Username</label>
                        <Input
                          value={oracleConfig.username}
                          onChange={(e) => setOracleConfig({ ...oracleConfig, username: e.target.value })}
                          placeholder="opc (Oracle Linux) or ubuntu"
                          className="mt-1.5"
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium">Port</label>
                        <Input
                          value={oracleConfig.port}
                          onChange={(e) => setOracleConfig({ ...oracleConfig, port: e.target.value })}
                          placeholder="22"
                          className="mt-1.5"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="text-sm font-medium">Private Key (PEM)</label>
                      <Textarea
                        value={oracleConfig.privateKey}
                        onChange={(e) => setOracleConfig({ ...oracleConfig, privateKey: e.target.value })}
                        placeholder="-----BEGIN RSA PRIVATE KEY-----&#10;MIIEpAIBAAKCAQEA...&#10;-----END RSA PRIVATE KEY-----"
                        className="mt-1.5 font-mono text-xs h-48"
                      />
                      <p className="text-xs text-muted-foreground mt-1.5">
                        Your SSH private key will be stored securely and encrypted
                      </p>
                    </div>

                    <div className="flex gap-2">
                      <Button 
                        onClick={handleSaveOracle} 
                        disabled={!oracleConfig.host} 
                        variant="outline"
                        className="flex-1"
                      >
                        Save Configuration
                      </Button>
                      <Button 
                        onClick={handleTestOracleSSH} 
                        disabled={testing || !oracleConfig.host} 
                        className="flex-1"
                      >
                        {testing ? 'Testing...' : 'Test Connection'}
                      </Button>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            {/* Detailed Setup Guide */}
            <Card className="bg-muted/30">
              <CardHeader>
                <CardTitle className="text-sm">Step-by-Step Oracle Cloud Setup</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 text-xs text-secondary-foreground">
                {/* Step 1 */}
                <div className="space-y-2">
                  <div className="flex items-start gap-2">
                    <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center shrink-0 mt-0.5">
                      <span className="text-[10px] font-bold text-primary">1</span>
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-foreground mb-1">Create Oracle Cloud Account & Compute Instance</p>
                      <ul className="space-y-1 ml-4 list-disc text-muted-foreground">
                        <li>Go to <a href="https://cloud.oracle.com" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">cloud.oracle.com</a> and sign up (free tier available)</li>
                        <li>Navigate to: <span className="font-mono bg-background px-1 rounded">Compute → Instances → Create Instance</span></li>
                        <li>Choose <span className="font-semibold">Ubuntu 22.04 Minimal</span> as the image</li>
                        <li>Select shape: <span className="font-semibold">VM.Standard.E2.1.Micro</span> (free tier eligible, 1 OCPU, 1GB RAM)</li>
                        <li>For production, consider: <span className="font-semibold">VM.Standard.E4.Flex</span> (2 OCPUs, 16GB RAM)</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Step 2 */}
                <div className="space-y-2">
                  <div className="flex items-start gap-2">
                    <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center shrink-0 mt-0.5">
                      <span className="text-[10px] font-bold text-primary">2</span>
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-foreground mb-1">Configure SSH Keys</p>
                      <ul className="space-y-1 ml-4 list-disc text-muted-foreground">
                        <li>During instance creation, select <span className="font-semibold">"Generate SSH key pair"</span></li>
                        <li>Click <span className="font-semibold">"Save Private Key"</span> and download the <span className="font-mono">.key</span> file</li>
                        <li>Store it securely (e.g., <span className="font-mono">~/.ssh/oracle-key.key</span>)</li>
                        <li>Set permissions: <span className="font-mono bg-background px-1 rounded">chmod 400 ~/.ssh/oracle-key.key</span></li>
                        <li>Copy the entire private key content and paste it in the "Private Key" field above</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Step 3 */}
                <div className="space-y-2">
                  <div className="flex items-start gap-2">
                    <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center shrink-0 mt-0.5">
                      <span className="text-[10px] font-bold text-primary">3</span>
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-foreground mb-1">Configure Network Security</p>
                      <ul className="space-y-1 ml-4 list-disc text-muted-foreground">
                        <li>Navigate to: <span className="font-mono bg-background px-1 rounded">Virtual Cloud Networks → Your VCN → Security Lists → Default Security List</span></li>
                        <li>Click <span className="font-semibold">"Add Ingress Rules"</span> and add:</li>
                        <li className="ml-4">Port <span className="font-semibold">22</span> (SSH) - Source: 0.0.0.0/0</li>
                        <li className="ml-4">Port <span className="font-semibold">80</span> (HTTP) - Source: 0.0.0.0/0</li>
                        <li className="ml-4">Port <span className="font-semibold">443</span> (HTTPS) - Source: 0.0.0.0/0</li>
                        <li className="ml-4">Port <span className="font-semibold">3000</span> (DocTasTic) - Source: 0.0.0.0/0</li>
                        <li>Click <span className="font-semibold">"Add Ingress Rules"</span> for each</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Step 4 */}
                <div className="space-y-2">
                  <div className="flex items-start gap-2">
                    <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center shrink-0 mt-0.5">
                      <span className="text-[10px] font-bold text-primary">4</span>
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-foreground mb-1">Configure Firewall</p>
                      <p className="mb-2 text-muted-foreground">If using <span className="font-semibold text-foreground">Oracle Linux</span> (opc user):</p>
                      <ul className="space-y-1 ml-4 list-disc text-muted-foreground">
                        <li>SSH into your instance: <span className="font-mono bg-background px-1 rounded">ssh -i ~/.ssh/oracle-key.key opc@YOUR_IP</span></li>
                        <li>Configure firewalld (pre-installed on Oracle Linux):</li>
                        <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo firewall-cmd --permanent --add-port=22/tcp</span></li>
                        <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo firewall-cmd --permanent --add-port=80/tcp</span></li>
                        <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo firewall-cmd --permanent --add-port=443/tcp</span></li>
                        <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo firewall-cmd --permanent --add-port=3000/tcp</span></li>
                        <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo firewall-cmd --reload</span></li>
                      </ul>
                      <p className="mt-2 mb-2 text-muted-foreground">If using <span className="font-semibold text-foreground">Ubuntu</span> (ubuntu user):</p>
                      <ul className="space-y-1 ml-4 list-disc text-muted-foreground">
                        <li>SSH into your instance: <span className="font-mono bg-background px-1 rounded">ssh -i ~/.ssh/oracle-key.key ubuntu@YOUR_IP</span></li>
                        <li>Install and configure UFW:</li>
                        <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo apt install ufw -y</span></li>
                        <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo ufw allow 22/tcp</span></li>
                        <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo ufw allow 80/tcp</span></li>
                        <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo ufw allow 443/tcp</span></li>
                        <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo ufw allow 3000/tcp</span></li>
                        <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo ufw enable</span></li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Step 5 */}
                <div className="space-y-2">
                  <div className="flex items-start gap-2">
                    <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center shrink-0 mt-0.5">
                      <span className="text-[10px] font-bold text-primary">5</span>
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-foreground mb-1">Get Instance IP & Test Connection</p>
                      <ul className="space-y-1 ml-4 list-disc text-muted-foreground">
                        <li>In Oracle Cloud Console, go to: <span className="font-mono bg-background px-1 rounded">Compute → Instances → Your Instance</span></li>
                        <li>Copy the <span className="font-semibold">Public IP Address</span></li>
                        <li>Paste it in the "Host / IP Address" field above</li>
                        <li>Click <span className="font-semibold">"Test SSH Connection"</span> to verify</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Step 6 */}
                <div className="space-y-2">
                  <div className="flex items-start gap-2">
                    <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center shrink-0 mt-0.5">
                      <span className="text-[10px] font-bold text-primary">6</span>
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-foreground mb-1">Install Prerequisites on Server</p>
                      <p className="mb-2 text-muted-foreground">For <span className="font-semibold text-foreground">Oracle Linux</span>:</p>
                      <ul className="space-y-1 ml-4 list-disc text-muted-foreground">
                        <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo dnf update -y</span></li>
                        <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo dnf install -y git curl gcc-c++ make</span></li>
                        <li className="ml-4"><span className="font-mono bg-background px-1 rounded">curl -fsSL https://rpm.nodesource.com/setup_20.x | sudo bash -</span></li>
                        <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo dnf install -y nodejs</span></li>
                        <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo npm install -g pm2</span></li>
                        <li>Install Docker: <span className="font-mono bg-background px-1 rounded">curl -fsSL https://get.docker.com | sh</span></li>
                        <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo usermod -aG docker opc</span></li>
                        <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo systemctl enable docker && sudo systemctl start docker</span></li>
                      </ul>
                      <p className="mt-2 mb-2 text-muted-foreground">For <span className="font-semibold text-foreground">Ubuntu</span>:</p>
                      <ul className="space-y-1 ml-4 list-disc text-muted-foreground">
                        <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo apt update && sudo apt upgrade -y</span></li>
                        <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo apt install -y git curl build-essential</span></li>
                        <li className="ml-4"><span className="font-mono bg-background px-1 rounded">curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -</span></li>
                        <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo apt install -y nodejs</span></li>
                        <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo npm install -g pm2</span></li>
                        <li>Install Docker: <span className="font-mono bg-background px-1 rounded">curl -fsSL https://get.docker.com | sh</span></li>
                        <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo usermod -aG docker ubuntu</span></li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="pt-2 border-t border-border">
                  <p className="text-muted-foreground italic text-[11px]">
                    💡 After completing these steps, proceed to the <span className="font-semibold text-foreground">GitHub Setup</span> tab (at the top of this page) to configure your repository, then click the <span className="font-semibold text-foreground">Deploy</span> tab to install DocTasTic.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* GitHub Tab */}
          <TabsContent value="github" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Github className="w-5 h-5" />
                  GitHub Repository Configuration
                </CardTitle>
                <CardDescription>
                  Connect to your GitHub repository for automated deployments
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {githubConnected && !githubEditing ? (
                  <>
                    <div className="flex items-center justify-between p-3 bg-primary/5 border border-primary/20 rounded-lg">
                      <div className="flex items-center gap-2 min-w-0">
                        <CheckCircle2 className="w-5 h-5 text-primary shrink-0" />
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-foreground truncate">{githubConfig.repoUrl}</p>
                          <p className="text-xs text-muted-foreground">Branch: {githubConfig.branch}</p>
                        </div>
                      </div>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => setGithubEditing(true)}
                        className="shrink-0"
                      >
                        <Edit2 className="w-4 h-4 mr-1" />
                        Edit
                      </Button>
                    </div>
                  </>
                ) : (
                  <>
                    <div>
                      <label className="text-sm font-medium">Repository URL</label>
                      <Input
                        value={githubConfig.repoUrl}
                        onChange={(e) => setGithubConfig({ ...githubConfig, repoUrl: e.target.value })}
                        placeholder="https://github.com/username/doctastic"
                        className="mt-1.5"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Personal Access Token</label>
                      <Input
                        type="password"
                        value={githubConfig.token}
                        onChange={(e) => setGithubConfig({ ...githubConfig, token: e.target.value })}
                        placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
                        className="mt-1.5"
                      />
                      <p className="text-xs text-muted-foreground mt-1.5">
                        Generate at: Settings → Developer settings → Personal access tokens
                      </p>
                    </div>
                    <div>
                      <label className="text-sm font-medium">Branch</label>
                      <Input
                        value={githubConfig.branch}
                        onChange={(e) => setGithubConfig({ ...githubConfig, branch: e.target.value })}
                        placeholder="main"
                        className="mt-1.5"
                      />
                    </div>

                    <div className="flex gap-2">
                      <Button 
                        onClick={handleSaveGitHub} 
                        disabled={!githubConfig.repoUrl} 
                        variant="outline"
                        className="flex-1"
                      >
                        Save Configuration
                      </Button>
                      <Button 
                        onClick={handleTestGitHub} 
                        disabled={testing || !githubConfig.repoUrl} 
                        className="flex-1"
                      >
                        {testing ? 'Testing...' : 'Test Connection'}
                      </Button>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Database & Hosting Tab */}
          <TabsContent value="database" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Database className="w-5 h-5" />
                  Database Setup & Hosting Configuration
                </CardTitle>
                <CardDescription>
                  Configure PostgreSQL database, replicate entities/authentication, and setup frontend/backend hosting
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <Card className="bg-muted/30">
                  <CardHeader>
                    <CardTitle className="text-sm">Complete Setup Guide</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4 text-xs text-secondary-foreground">
                    
                    {/* Step 1: Database Setup */}
                    <div className="space-y-2">
                      <div className="flex items-start gap-2">
                        <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center shrink-0 mt-0.5">
                          <span className="text-[10px] font-bold text-primary">1</span>
                        </div>
                        <div className="flex-1">
                          <p className="font-semibold text-foreground mb-1">Install PostgreSQL Database</p>
                          <p className="mb-2 text-muted-foreground">Run in <span className="font-semibold text-foreground">SSH Terminal</span> - For <span className="font-semibold text-foreground">Oracle Linux</span>:</p>
                          <ul className="space-y-1 ml-4 list-disc text-muted-foreground">
                            <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo dnf install postgresql postgresql-server postgresql-contrib -y</span></li>
                            <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo postgresql-setup --initdb</span></li>
                            <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo systemctl enable postgresql && sudo systemctl start postgresql</span></li>
                            <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo -u postgres psql</span> (enters PostgreSQL shell)</li>
                          </ul>
                          <p className="mt-2 mb-2 text-muted-foreground">Run in <span className="font-semibold text-foreground">SSH Terminal</span> - For <span className="font-semibold text-foreground">Ubuntu</span>:</p>
                          <ul className="space-y-1 ml-4 list-disc text-muted-foreground">
                            <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo apt install postgresql postgresql-contrib -y</span></li>
                            <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo systemctl enable postgresql && sudo systemctl start postgresql</span></li>
                            <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo -u postgres psql</span> (enters PostgreSQL shell)</li>
                          </ul>
                          <p className="mt-2 text-yellow-500/70 text-[11px] italic">
                            ℹ️ You may see "could not change directory" warning - this is normal and can be safely ignored. PostgreSQL will still work correctly.
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Step 2: Create Database */}
                    <div className="space-y-2">
                      <div className="flex items-start gap-2">
                        <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center shrink-0 mt-0.5">
                          <span className="text-[10px] font-bold text-primary">2</span>
                        </div>
                        <div className="flex-1">
                          <p className="font-semibold text-foreground mb-1">Create DocTasTic Database & User</p>
                          <p className="mb-2 text-muted-foreground">Run in <span className="font-semibold text-foreground">PostgreSQL Shell</span> (postgres=#):</p>
                          <ul className="space-y-1 ml-4 list-disc text-muted-foreground">
                            <li className="ml-4"><span className="font-mono bg-background px-1 rounded">CREATE DATABASE doctastic;</span></li>
                            <li className="ml-4"><span className="font-mono bg-background px-1 rounded">CREATE USER doctastic_user WITH PASSWORD 'your_secure_password';</span></li>
                            <li className="ml-4"><span className="font-mono bg-background px-1 rounded">GRANT ALL PRIVILEGES ON DATABASE doctastic TO doctastic_user;</span></li>
                            <li className="ml-4"><span className="font-mono bg-background px-1 rounded">\q</span> (exit to SSH terminal)</li>
                          </ul>
                          <p className="mt-2 mb-2 text-muted-foreground">Run in <span className="font-semibold text-foreground">SSH Terminal</span> - Configure password authentication:</p>
                          <ul className="space-y-1 ml-4 list-disc text-muted-foreground">
                            <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo nano /var/lib/pgsql/data/pg_hba.conf</span> (Oracle Linux)</li>
                            <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo nano /etc/postgresql/13/main/pg_hba.conf</span> (Ubuntu)</li>
                            <li className="ml-4">Find the line: <span className="font-mono bg-background px-0.5 text-[10px]">local all all peer</span></li>
                            <li className="ml-4">Change to: <span className="font-mono bg-background px-0.5 text-[10px]">local all all md5</span></li>
                            <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo systemctl restart postgresql</span></li>
                            <li className="ml-4">Test connection: <span className="font-mono bg-background px-1 rounded">psql -U doctastic_user -d doctastic</span></li>
                          </ul>
                        </div>
                      </div>
                    </div>

                    {/* Step 3: Setup Entity Tables */}
                    <div className="space-y-2">
                      <div className="flex items-start gap-2">
                        <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center shrink-0 mt-0.5">
                          <span className="text-[10px] font-bold text-primary">3</span>
                        </div>
                        <div className="flex-1">
                          <p className="font-semibold text-foreground mb-1">Replicate Entity Schema</p>
                          <p className="mb-2 text-muted-foreground">Run in <span className="font-semibold text-foreground">SSH Terminal</span> - Connect to database:</p>
                          <ul className="space-y-1 ml-4 list-disc text-muted-foreground">
                            <li className="ml-4"><span className="font-mono bg-background px-1 rounded">psql -U doctastic_user -d doctastic</span> (enters PostgreSQL shell)</li>
                          </ul>
                          <p className="mt-2 mb-2 text-muted-foreground">Run in <span className="font-semibold text-foreground">PostgreSQL Shell</span> (doctastic=&gt;) - Create tables:</p>
                          <ul className="space-y-1 ml-4 list-disc text-muted-foreground">
                            <li className="ml-4 mt-2">Create <span className="font-semibold">sessions</span> table:</li>
                            <li className="ml-8"><span className="font-mono bg-background px-0.5 text-[10px]">CREATE TABLE sessions (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), created_date TIMESTAMP DEFAULT NOW(), updated_date TIMESTAMP DEFAULT NOW(), created_by VARCHAR(255), title TEXT NOT NULL, status VARCHAR(50) DEFAULT 'running', planner_items JSONB DEFAULT '[]', shell_history JSONB DEFAULT '[]', files JSONB DEFAULT '[]', browser_url TEXT);</span></li>
                            <li className="ml-4 mt-2">Create <span className="font-semibold">skills</span> table:</li>
                            <li className="ml-8"><span className="font-mono bg-background px-0.5 text-[10px]">CREATE TABLE skills (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), created_date TIMESTAMP DEFAULT NOW(), updated_date TIMESTAMP DEFAULT NOW(), created_by VARCHAR(255), name VARCHAR(255) NOT NULL, description TEXT, content TEXT NOT NULL, category VARCHAR(50) DEFAULT 'other');</span></li>
                            <li className="ml-4 mt-2">Create <span className="font-semibold">chat_messages</span> table:</li>
                            <li className="ml-8"><span className="font-mono bg-background px-0.5 text-[10px]">CREATE TABLE chat_messages (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), created_date TIMESTAMP DEFAULT NOW(), updated_date TIMESTAMP DEFAULT NOW(), created_by VARCHAR(255), session_id VARCHAR(255) NOT NULL, role VARCHAR(50) NOT NULL, content TEXT NOT NULL, message_type VARCHAR(50) DEFAULT 'text');</span></li>
                          </ul>
                        </div>
                      </div>
                    </div>

                    {/* Step 4: Authentication Setup */}
                    <div className="space-y-2">
                      <div className="flex items-start gap-2">
                        <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center shrink-0 mt-0.5">
                          <span className="text-[10px] font-bold text-primary">4</span>
                        </div>
                        <div className="flex-1">
                          <p className="font-semibold text-foreground mb-1">Setup Authentication System</p>
                          <p className="mb-2 text-muted-foreground">Run in <span className="font-semibold text-foreground">PostgreSQL Shell</span> (doctastic=&gt;) - Create users table:</p>
                          <ul className="space-y-1 ml-4 list-disc text-muted-foreground">
                            <li className="ml-4">Create <span className="font-semibold">users</span> table:</li>
                            <li className="ml-8"><span className="font-mono bg-background px-0.5 text-[10px]">CREATE TABLE users (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), created_date TIMESTAMP DEFAULT NOW(), updated_date TIMESTAMP DEFAULT NOW(), email VARCHAR(255) UNIQUE NOT NULL, full_name VARCHAR(255), password_hash VARCHAR(255) NOT NULL, role VARCHAR(50) DEFAULT 'user');</span></li>
                            <li className="ml-8"><span className="font-mono bg-background px-1 rounded">\q</span> (exit to SSH terminal)</li>
                          </ul>
                          <p className="mt-2 mb-2 text-muted-foreground">Run in <span className="font-semibold text-foreground">SSH Terminal</span> - Install dependencies:</p>
                          <ul className="space-y-1 ml-4 list-disc text-muted-foreground">
                            <li className="ml-4">Install bcrypt for password hashing:</li>
                            <li className="ml-8"><span className="font-mono bg-background px-1 rounded">npm install bcrypt jsonwebtoken</span></li>
                            <li className="ml-4 mt-2">Configure JWT secret in <span className="font-mono">.env</span> file:</li>
                            <li className="ml-8"><span className="font-mono bg-background px-1 rounded">JWT_SECRET=your_random_secure_secret_key_here</span></li>
                            <li className="ml-8"><span className="font-mono bg-background px-1 rounded">DATABASE_URL=postgresql://doctastic_user:your_secure_password@localhost:5432/doctastic</span></li>
                          </ul>
                        </div>
                      </div>
                    </div>

                    {/* Step 5: Backend API Setup */}
                    <div className="space-y-2">
                      <div className="flex items-start gap-2">
                        <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center shrink-0 mt-0.5">
                          <span className="text-[10px] font-bold text-primary">5</span>
                        </div>
                        <div className="flex-1">
                          <p className="font-semibold text-foreground mb-1">Setup Backend API Server</p>
                          <p className="mb-2 text-muted-foreground">Run in <span className="font-semibold text-foreground">SSH Terminal</span> - Create Node.js/Express backend:</p>
                          <ul className="space-y-1 ml-4 list-disc text-muted-foreground">
                            <li className="ml-4">Install backend dependencies:</li>
                            <li className="ml-8"><span className="font-mono bg-background px-1 rounded">npm install express cors pg dotenv express-session</span></li>
                            <li className="ml-4 mt-2">Create <span className="font-mono">server/index.js</span> with:</li>
                            <li className="ml-8">- Express app configuration</li>
                            <li className="ml-8">- CORS middleware (allow frontend origin)</li>
                            <li className="ml-8">- PostgreSQL connection pool</li>
                            <li className="ml-8">- Authentication routes (/api/auth/login, /api/auth/register, /api/auth/me)</li>
                            <li className="ml-8">- Entity CRUD routes (/api/sessions, /api/skills, /api/chat-messages)</li>
                            <li className="ml-4 mt-2">Run backend on port 3001:</li>
                            <li className="ml-8"><span className="font-mono bg-background px-1 rounded">node server/index.js</span></li>
                            <li className="ml-4 mt-2">Use PM2 for production:</li>
                            <li className="ml-8"><span className="font-mono bg-background px-1 rounded">pm2 start server/index.js --name doctastic-backend</span></li>
                            <li className="ml-8"><span className="font-mono bg-background px-1 rounded">pm2 save && pm2 startup</span></li>
                          </ul>
                        </div>
                      </div>
                    </div>

                    {/* Step 6: Frontend Build & Hosting */}
                    <div className="space-y-2">
                      <div className="flex items-start gap-2">
                        <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center shrink-0 mt-0.5">
                          <span className="text-[10px] font-bold text-primary">6</span>
                        </div>
                        <div className="flex-1">
                          <p className="font-semibold text-foreground mb-1">Build & Host Frontend</p>
                          <p className="mb-2 text-muted-foreground">Run in <span className="font-semibold text-foreground">SSH Terminal</span> - Build and configure:</p>
                          <ul className="space-y-1 ml-4 list-disc text-muted-foreground">
                            <li className="ml-4">Build the frontend:</li>
                            <li className="ml-8"><span className="font-mono bg-background px-1 rounded">npm run build</span></li>
                            <li className="ml-4 mt-2">Install Nginx (Oracle Linux):</li>
                            <li className="ml-8"><span className="font-mono bg-background px-1 rounded">sudo dnf install nginx -y</span></li>
                            <li className="ml-4 mt-2">Install Nginx (Ubuntu):</li>
                            <li className="ml-8"><span className="font-mono bg-background px-1 rounded">sudo apt install nginx -y</span></li>
                            <li className="ml-4 mt-2">Configure Nginx (<span className="font-mono">/etc/nginx/sites-available/doctastic</span>):</li>
                            <li className="ml-8"><span className="font-mono bg-background px-0.5 text-[10px]">server {"{"} listen 80; server_name your_domain_or_ip; root /path/to/dist; index index.html; location / {"{"} try_files $uri $uri/ /index.html; {"}"} location /api {"{"} proxy_pass http://localhost:3001; proxy_http_version 1.1; proxy_set_header Upgrade $http_upgrade; proxy_set_header Connection 'upgrade'; {"}"} {"}"}</span></li>
                            <li className="ml-4 mt-2">Enable and restart Nginx:</li>
                            <li className="ml-8"><span className="font-mono bg-background px-1 rounded">sudo ln -s /etc/nginx/sites-available/doctastic /etc/nginx/sites-enabled/</span></li>
                            <li className="ml-8"><span className="font-mono bg-background px-1 rounded">sudo nginx -t && sudo systemctl restart nginx</span></li>
                          </ul>
                        </div>
                      </div>
                    </div>

                    {/* Step 7: SSL/HTTPS Setup */}
                    <div className="space-y-2">
                      <div className="flex items-start gap-2">
                        <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center shrink-0 mt-0.5">
                          <span className="text-[10px] font-bold text-primary">7</span>
                        </div>
                        <div className="flex-1">
                          <p className="font-semibold text-foreground mb-1">Optional: Setup SSL with Let's Encrypt</p>
                          <p className="mb-2 text-muted-foreground">Run in <span className="font-semibold text-foreground">SSH Terminal</span> - For <span className="font-semibold text-foreground">Oracle Linux</span>:</p>
                          <ul className="space-y-1 ml-4 list-disc text-muted-foreground">
                            <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo dnf install certbot python3-certbot-nginx -y</span></li>
                            <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo certbot --nginx -d your_domain.com</span></li>
                          </ul>
                          <p className="mt-2 mb-2 text-muted-foreground">For <span className="font-semibold text-foreground">Ubuntu</span>:</p>
                          <ul className="space-y-1 ml-4 list-disc text-muted-foreground">
                            <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo apt install certbot python3-certbot-nginx -y</span></li>
                            <li className="ml-4"><span className="font-mono bg-background px-1 rounded">sudo certbot --nginx -d your_domain.com</span></li>
                          </ul>
                          <p className="mt-2 text-muted-foreground">Follow prompts to configure HTTPS - Certbot will auto-renew certificates</p>
                        </div>
                      </div>
                    </div>

                    {/* Step 8: Environment Variables */}
                    <div className="space-y-2">
                      <div className="flex items-start gap-2">
                        <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center shrink-0 mt-0.5">
                          <span className="text-[10px] font-bold text-primary">8</span>
                        </div>
                        <div className="flex-1">
                          <p className="font-semibold text-foreground mb-1">Configure Environment Variables</p>
                          <p className="mb-2 text-muted-foreground">Run in <span className="font-semibold text-foreground">SSH Terminal</span> - Create <span className="font-mono">.env</span> file:</p>
                          <ul className="space-y-1 ml-4 list-disc text-muted-foreground">
                            <li className="ml-4"><span className="font-mono bg-background px-1 rounded">DATABASE_URL=postgresql://doctastic_user:password@localhost:5432/doctastic</span></li>
                            <li className="ml-4"><span className="font-mono bg-background px-1 rounded">JWT_SECRET=your_secret_key_here</span></li>
                            <li className="ml-4"><span className="font-mono bg-background px-1 rounded">NODE_ENV=production</span></li>
                            <li className="ml-4"><span className="font-mono bg-background px-1 rounded">PORT=3001</span></li>
                            <li className="ml-4"><span className="font-mono bg-background px-1 rounded">FRONTEND_URL=http://your_domain_or_ip</span></li>
                          </ul>
                        </div>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-border">
                      <p className="text-muted-foreground italic text-[11px]">
                        💡 This setup provides a complete self-hosted solution with PostgreSQL database, user authentication, RESTful API backend, and production-ready frontend hosting on Oracle Cloud.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Deploy Tab */}
          <TabsContent value="deploy" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Terminal className="w-5 h-5" />
                  Deployment Configuration
                </CardTitle>
                <CardDescription>
                  Deploy DocTasTic to your Oracle Cloud instance
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Status Grid */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div className={`p-4 rounded-lg border ${oracleConnected ? 'bg-primary/5 border-primary/20' : 'bg-muted border-border'}`}>
                    <div className="flex items-center gap-2 mb-2">
                      {oracleConnected ? (
                        <CheckCircle2 className="w-5 h-5 text-primary" />
                      ) : (
                        <AlertCircle className="w-5 h-5 text-muted-foreground" />
                      )}
                      <span className="font-semibold text-sm">Oracle Cloud SSH</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {oracleConnected ? 'Connected and ready' : 'Not configured'}
                    </p>
                  </div>
                  <div className={`p-4 rounded-lg border ${githubConnected ? 'bg-primary/5 border-primary/20' : 'bg-muted border-border'}`}>
                    <div className="flex items-center gap-2 mb-2">
                      {githubConnected ? (
                        <CheckCircle2 className="w-5 h-5 text-primary" />
                      ) : (
                        <AlertCircle className="w-5 h-5 text-muted-foreground" />
                      )}
                      <span className="font-semibold text-sm">GitHub Repository</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {githubConnected ? 'Connected and ready' : 'Not configured'}
                    </p>
                  </div>
                </div>

                {/* Deployment Steps */}
                <Card className="bg-muted/30">
                  <CardHeader>
                    <CardTitle className="text-sm">Deployment Process</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 text-xs text-secondary-foreground">
                    <div className="flex items-center gap-2">
                      <Database className="w-4 h-4 text-primary" />
                      <span>Clone repository to Oracle Cloud instance</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Terminal className="w-4 h-4 text-primary" />
                      <span>Install dependencies and configure environment</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Server className="w-4 h-4 text-primary" />
                      <span>Setup database and backend services</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-primary" />
                      <span>Deploy and start DocTasTic application</span>
                    </div>
                  </CardContent>
                </Card>

{deployed ? (
                  <div className="flex items-center justify-center gap-2 w-full py-3 bg-primary/10 border border-primary/20 rounded-lg text-primary">
                    <CheckCircle2 className="w-5 h-5" />
                    <span className="font-semibold">Successfully Deployed</span>
                  </div>
                ) : (
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button 
                        disabled={!oracleConnected || !githubConnected || testing}
                        className="w-full"
                        size="lg"
                      >
                        {testing ? 'Deploying...' : 'Deploy DocTasTic to Oracle Cloud'}
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Confirm Deployment</AlertDialogTitle>
                        <AlertDialogDescription className="space-y-2">
                          <p>This will deploy DocTasTic to your Oracle Cloud instance with the following configuration:</p>
                          <div className="mt-3 space-y-1 text-sm">
                            <p><span className="font-semibold">Host:</span> {oracleConfig.host}</p>
                            <p><span className="font-semibold">Repository:</span> {githubConfig.repoUrl}</p>
                            <p><span className="font-semibold">Branch:</span> {githubConfig.branch}</p>
                          </div>
                          <p className="mt-3">The deployment process will take several minutes. Continue?</p>
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={handleDeploy}>Deploy Now</AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                )}

                {(!oracleConnected || !githubConnected) && (
                  <p className="text-xs text-center text-muted-foreground">
                    Please configure both Oracle Cloud SSH and GitHub connections before deploying
                  </p>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}