import React from 'react';
import { BookOpen, CheckCircle2, Code2, Bug, RefreshCw, FileCode, Zap, Users } from 'lucide-react';

const taskCategories = [
  {
    title: "Tackling Tasks in Parallel",
    icon: Zap,
    items: [
      "Linear/Jira tickets",
      "Entire features from scratch",
      "Bug reports",
      "App testing",
    ]
  },
  {
    title: "Code Migrations & Refactoring",
    icon: RefreshCw,
    items: [
      "Code migrations, refactors, and modernization",
      "Language migrations (e.g. JavaScript to TypeScript)",
      "Framework upgrades (e.g. Angular 16 → 18)",
      "Monorepo to submodule conversions",
      "Removing unused feature flags",
      "Extracting common code into libraries",
    ]
  },
  {
    title: "Engineering Support",
    icon: Users,
    items: [
      "PR Review",
      "Codebase Q&A",
      "Reproducing & fixing bugs",
      "Writing unit tests",
      "Maintaining documentation",
      "Customer engineering support",
    ]
  },
  {
    title: "Building & Integration",
    icon: Code2,
    items: [
      "Building new integrations and working with unfamiliar APIs",
      "Creating customized demos",
      "Prototyping solutions",
      "Building internal tools",
    ]
  },
];

const bestPractices = [
  "Write clear prompts with explicit completion criteria — the clearer the task, the higher the success rate",
  "Make tasks easy to verify — e.g. checking that CI passes or testing an automatic deployment",
  "For harder tasks, break them into well-scoped steps and provide relevant context or examples",
];

const workflows = [
  "Tagging DocTasTic on a Slack or Teams thread about a bug you're discussing with coworkers",
  "Delegating a more complex task via the web application and taking over in DocTasTic's IDE once it gives you a good first draft",
  "Carving out tasks from your todo list at the start of your day and returning to draft PRs waiting for review",
];

const features = [
  {
    title: "Shell",
    icon: Code2,
    description: "DocTasTic's terminal, where you can watch commands being executed and view output logs. You can also copy the shell output for debugging purposes.",
  },
  {
    title: "IDE",
    icon: FileCode,
    description: "DocTasTic's embedded code editor equipped with all the IDE tools and shortcuts you're familiar with. Follow DocTasTic's work real-time and take over to run commands, make direct code edits or test DocTasTic's code.",
  },
  {
    title: "Browser",
    icon: BookOpen,
    description: "Watch DocTasTic browse through documentation, test web applications it builds, download/upload information, and more. You can jump in to help DocTasTic navigate through browsing tasks via the Interactive Browser.",
  },
];

export default function Docs() {
  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-5xl mx-auto px-6 py-12 space-y-12">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="w-16 h-16 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center">
              <BookOpen className="w-8 h-8 text-primary" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-foreground">DocTasTic Documentation</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Your AI software engineer that excels at tackling complex development tasks, migrations, and building features from scratch.
          </p>
        </div>

        {/* Where DocTasTic Excels */}
        <section className="space-y-6">
          <h2 className="text-2xl font-semibold text-foreground flex items-center gap-2">
            <CheckCircle2 className="w-6 h-6 text-primary" />
            Where DocTasTic Excels
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            {taskCategories.map((category) => {
              const Icon = category.icon;
              return (
                <div key={category.title} className="bg-card border border-border rounded-xl p-6 space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Icon className="w-5 h-5 text-primary" />
                    </div>
                    <h3 className="text-lg font-semibold text-foreground">{category.title}</h3>
                  </div>
                  <ul className="space-y-2">
                    {category.items.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-sm text-secondary-foreground">
                        <CheckCircle2 className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>
        </section>

        {/* Best Practices */}
        <section className="space-y-6">
          <h2 className="text-2xl font-semibold text-foreground">Getting the Best Results</h2>
          <div className="bg-card border border-border rounded-xl p-6 space-y-4">
            {bestPractices.map((practice, idx) => (
              <div key={idx} className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                  <span className="text-xs font-semibold text-primary">{idx + 1}</span>
                </div>
                <p className="text-sm text-secondary-foreground">{practice}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Successful Workflows */}
        <section className="space-y-6">
          <h2 className="text-2xl font-semibold text-foreground">Most Successful Workflows</h2>
          <div className="space-y-3">
            {workflows.map((workflow, idx) => (
              <div key={idx} className="bg-card border border-border rounded-xl p-4 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                <p className="text-sm text-secondary-foreground">{workflow}</p>
              </div>
            ))}
          </div>
          <p className="text-sm text-muted-foreground italic">
            DocTasTic is most effective when it's part of your team and your existing workflow.
          </p>
        </section>

        {/* The Interface */}
        <section className="space-y-6">
          <h2 className="text-2xl font-semibold text-foreground">The DocTasTic Interface</h2>
          <p className="text-secondary-foreground">
            DocTasTic is designed to be a conversational user interface, and allows you to follow and take over DocTasTic's development process in the embedded workspace.
          </p>
          <div className="grid md:grid-cols-3 gap-6">
            {features.map((feature) => {
              const Icon = feature.icon;
              return (
                <div key={feature.title} className="bg-card border border-border rounded-xl p-6 space-y-3">
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground">{feature.title}</h3>
                  <p className="text-sm text-secondary-foreground leading-relaxed">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </section>

        {/* Skills Section */}
        <section className="space-y-6">
          <h2 className="text-2xl font-semibold text-foreground">Skills</h2>
          <div className="bg-card border border-border rounded-xl p-6 space-y-4">
            <p className="text-secondary-foreground">
              Teach DocTasTic reusable procedures by committing <code className="px-2 py-0.5 bg-background rounded text-xs font-mono text-primary">SKILL.md</code> files to your repos.
            </p>
            <div className="space-y-2">
              <h3 className="text-sm font-semibold text-foreground">What are Skills?</h3>
              <p className="text-sm text-secondary-foreground">
                Skills are SKILL.md files you commit to your repositories that teach DocTasTic reusable procedures — any repeatable workflow you want DocTasTic to follow consistently. Testing your app before opening a PR, deploying to an environment, investigating a codebase, scaffolding a new service — if you can write it as step-by-step instructions, you can turn it into a skill.
              </p>
            </div>
            <div className="bg-background rounded-lg p-4 border border-border">
              <p className="text-xs font-mono text-muted-foreground">
                Place skill files at <span className="text-primary">.agents/skills/&lt;skill-name&gt;/SKILL.md</span> in your repository.
              </p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}