import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Send, Plus, Sparkles, GitBranch, Bug, RefreshCw } from 'lucide-react';
import DevinLogo from '@/components/home/DevinLogo';
import { motion } from 'framer-motion';

const suggestions = [
  { icon: Sparkles, label: 'Build a feature', description: 'Create a new component or page' },
  { icon: Bug, label: 'Fix a bug', description: 'Debug and resolve an issue' },
  { icon: RefreshCw, label: 'Refactor code', description: 'Improve existing code structure' },
  { icon: GitBranch, label: 'Code migration', description: 'Upgrade or migrate your codebase' },
];

export default function Home() {
  const [prompt, setPrompt] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const navigate = useNavigate();

  const handleCreateSession = async (text) => {
    const sessionPrompt = text || prompt;
    if (!sessionPrompt.trim()) return;
    
    setIsCreating(true);
    const session = await base44.entities.Session.create({
      title: sessionPrompt.trim().slice(0, 100),
      status: 'running',
      planner_items: [],
      shell_history: [],
      files: [],
      browser_url: '',
    });
    navigate(`/session/${session.id}?prompt=${encodeURIComponent(sessionPrompt.trim())}`);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleCreateSession();
    }
  };

  return (
    <div className="h-full flex flex-col items-center justify-center px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-2xl text-center"
      >
        {/* Logo */}
        <div className="flex justify-center mb-8">
          <motion.div
            animate={{ rotate: [0, 5, -5, 0] }}
            transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
          >
            <DevinLogo size={56} />
          </motion.div>
        </div>

        {/* Input area */}
        <div className="relative mb-6">
          <div className="bg-card border border-border rounded-2xl overflow-hidden focus-within:border-primary/40 transition-colors shadow-lg shadow-black/20">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask DocTasTic to build features, fix bugs, or work on your code"
              className="w-full bg-transparent text-sm text-foreground placeholder:text-muted-foreground resize-none outline-none p-4 pb-2 min-h-[60px] max-h-[200px]"
              rows={2}
              disabled={isCreating}
            />
            <div className="flex items-center justify-between px-4 pb-3">
              <button className="text-muted-foreground hover:text-foreground transition-colors">
                <Plus className="w-4 h-4" />
              </button>
              <button
                onClick={() => handleCreateSession()}
                disabled={!prompt.trim() || isCreating}
                className="w-7 h-7 rounded-full bg-primary flex items-center justify-center text-primary-foreground hover:bg-primary/90 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Suggestion cards */}
        <div className="grid grid-cols-2 gap-3 max-w-lg mx-auto">
          {suggestions.map((item) => {
            const Icon = item.icon;
            return (
              <motion.button
                key={item.label}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => {
                  setPrompt(item.description);
                  handleCreateSession(item.description);
                }}
                disabled={isCreating}
                className="flex items-start gap-3 p-3 rounded-xl border border-border bg-card/50 hover:bg-card hover:border-primary/20 transition-all text-left group"
              >
                <Icon className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs font-medium text-foreground">{item.label}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{item.description}</p>
                </div>
              </motion.button>
            );
          })}
        </div>
      </motion.div>
    </div>
  );
}