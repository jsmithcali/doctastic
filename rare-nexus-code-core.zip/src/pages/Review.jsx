import React from 'react';
import { GitPullRequest, Search } from 'lucide-react';

export default function Review() {
  return (
    <div className="h-full flex flex-col items-center justify-center px-4">
      <div className="w-full max-w-xl text-center">
        <div className="flex justify-center mb-6">
          <div className="w-14 h-14 rounded-2xl bg-card border border-border flex items-center justify-center">
            <GitPullRequest className="w-6 h-6 text-primary" />
          </div>
        </div>
        <h1 className="text-xl font-semibold text-foreground mb-2">DocTasTic Review</h1>
        <p className="text-sm text-muted-foreground mb-8">
          AI-powered code review for your pull requests
        </p>

        <div className="space-y-3 max-w-md mx-auto">
          {[
            { title: 'No open reviews', desc: 'Connect a repository to start using DocTasTic Review' },
          ].map((item, i) => (
            <div key={i} className="p-6 rounded-xl border border-dashed border-border bg-card/30 text-center">
              <p className="text-xs font-medium text-muted-foreground">{item.title}</p>
              <p className="text-[10px] text-muted-foreground mt-1">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}