import React, { useState, useEffect, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import ChatPanel from '@/components/session/ChatPanel';
import WorkspacePanel from '@/components/session/WorkspacePanel';
import SessionSidebar from '@/components/session/SessionSidebar';

export default function Session() {
  const { id } = useParams();
  const queryClient = useQueryClient();
  const [isProcessing, setIsProcessing] = useState(false);

  // Get initial prompt from URL
  const urlParams = new URLSearchParams(window.location.search);
  const initialPrompt = urlParams.get('prompt');
  const [hasProcessedInitial, setHasProcessedInitial] = useState(false);

  const { data: session } = useQuery({
    queryKey: ['session', id],
    queryFn: () => base44.entities.Session.filter({ id }),
    select: (data) => data[0],
    enabled: !!id,
  });

  const { data: messages = [] } = useQuery({
    queryKey: ['messages', id],
    queryFn: () => base44.entities.ChatMessage.filter({ session_id: id }, 'created_date'),
    enabled: !!id,
  });

  const processMessage = useCallback(async (userMessage) => {
    setIsProcessing(true);

    // Save user message
    await base44.entities.ChatMessage.create({
      session_id: id,
      role: 'user',
      content: userMessage,
      message_type: 'text',
    });
    queryClient.invalidateQueries({ queryKey: ['messages', id] });

    // Generate AI response
    const planResponse = await base44.integrations.Core.InvokeLLM({
      prompt: `You are DocTasTic, an AI software engineer. The user asked: "${userMessage}"

Generate a response as if you're an AI coding agent starting to work on this task. Include:
1. A brief acknowledgment of the task
2. Your plan of action (what steps you'll take)
3. Mention specific technologies/files you'll work with

Keep it concise and professional. Use markdown formatting.`,
      response_json_schema: {
        type: "object",
        properties: {
          response: { type: "string", description: "The main response message in markdown" },
          plan_items: {
            type: "array",
            items: {
              type: "object",
              properties: {
                text: { type: "string" },
                substeps: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      text: { type: "string" }
                    }
                  }
                }
              }
            }
          },
          shell_commands: {
            type: "array",
            items: {
              type: "object",
              properties: {
                command: { type: "string" },
                output: { type: "string" }
              }
            }
          },
          files: {
            type: "array",
            items: {
              type: "object",
              properties: {
                name: { type: "string" },
                path: { type: "string" },
                content: { type: "string" },
                language: { type: "string" }
              }
            }
          },
          browser_url: { type: "string" }
        }
      }
    });

    // Save assistant response
    await base44.entities.ChatMessage.create({
      session_id: id,
      role: 'assistant',
      content: planResponse.response,
      message_type: 'text',
    });

    // Update session with workspace data - preserve existing data if resuming
    const existingPlanItems = session?.planner_items || [];
    const newPlanItems = planResponse.plan_items || [];
    const planItems = [...existingPlanItems, ...newPlanItems].map(item => ({
      ...item,
      completed: item.completed || false,
      substeps: (item.substeps || []).map(s => ({ ...s, completed: s.completed || false }))
    }));

    const existingShellHistory = session?.shell_history || [];
    const existingFiles = session?.files || [];

    await base44.entities.Session.update(id, {
      planner_items: planItems,
      shell_history: [...existingShellHistory, ...(planResponse.shell_commands || [])],
      files: [...existingFiles, ...(planResponse.files || [])],
      browser_url: planResponse.browser_url || session?.browser_url || '',
    });

    queryClient.invalidateQueries({ queryKey: ['messages', id] });
    queryClient.invalidateQueries({ queryKey: ['session', id] });
    setIsProcessing(false);

    // Simulate completing plan items
    simulateProgress(planItems);
  }, [id, queryClient]);

  const simulateProgress = useCallback(async (planItems) => {
    if (!planItems.length) return;
    
    for (let i = 0; i < planItems.length; i++) {
      await new Promise(r => setTimeout(r, 3000 + Math.random() * 2000));
      
      const updated = planItems.map((item, idx) => ({
        ...item,
        completed: idx <= i,
        substeps: (item.substeps || []).map((s, sIdx) => ({
          ...s,
          completed: idx < i || (idx === i)
        }))
      }));

      await base44.entities.Session.update(id, { planner_items: updated });
      queryClient.invalidateQueries({ queryKey: ['session', id] });

      // Add status message for completed step
      await base44.entities.ChatMessage.create({
        session_id: id,
        role: 'assistant',
        content: `✓ Completed: **${planItems[i].text}**`,
        message_type: 'status',
      });
      queryClient.invalidateQueries({ queryKey: ['messages', id] });
    }

    // Mark session as completed
    await base44.entities.Session.update(id, { status: 'completed' });
    await base44.entities.ChatMessage.create({
      session_id: id,
      role: 'assistant',
      content: "I've completed all the planned tasks. Let me know if you'd like to make any changes or have follow-up requests!",
      message_type: 'text',
    });
    queryClient.invalidateQueries({ queryKey: ['session', id] });
    queryClient.invalidateQueries({ queryKey: ['messages', id] });
  }, [id, queryClient]);

  // Process initial prompt
  useEffect(() => {
    if (initialPrompt && !hasProcessedInitial && id) {
      setHasProcessedInitial(true);
      // Clear the URL param
      window.history.replaceState({}, '', `/session/${id}`);
      processMessage(initialPrompt);
    }
  }, [initialPrompt, hasProcessedInitial, id, processMessage]);

  const handleSendMessage = (content) => {
    processMessage(content);
  };

  const handleSessionUpdate = () => {
    queryClient.invalidateQueries({ queryKey: ['session', id] });
    queryClient.invalidateQueries({ queryKey: ['sessions'] });
  };

  return (
    <div className="h-full flex">
      <SessionSidebar currentSessionId={id} />
      <div className="flex-1 flex min-w-0">
        {/* Chat Panel */}
        <div className="w-[380px] shrink-0 border-r border-border flex flex-col">
          <ChatPanel
            messages={messages}
            onSendMessage={handleSendMessage}
            isProcessing={isProcessing}
            sessionStatus={session?.status}
            session={session}
            onSessionUpdate={handleSessionUpdate}
          />
        </div>
        {/* Workspace Panel */}
        <div className="flex-1 min-w-0">
          <WorkspacePanel session={session} />
        </div>
      </div>
    </div>
  );
}