import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { BookOpen, Plus, Trash2, Edit2, FileCode, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { toast } from 'sonner';

export default function Skills() {
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingSkill, setEditingSkill] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    content: '',
  });

  const { data: skills = [] } = useQuery({
    queryKey: ['skills'],
    queryFn: async () => {
      // Skills stored as files in a hypothetical skills entity
      return base44.entities.Skill?.list?.() || [];
    },
    initialData: [],
  });

  const createSkillMutation = useMutation({
    mutationFn: async (data) => {
      return base44.entities.Skill?.create?.(data) || Promise.resolve();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['skills'] });
      setDialogOpen(false);
      resetForm();
      toast.success('Skill created successfully');
    },
  });

  const deleteSkillMutation = useMutation({
    mutationFn: async (id) => {
      return base44.entities.Skill?.delete?.(id) || Promise.resolve();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['skills'] });
      toast.success('Skill deleted');
    },
  });

  const resetForm = () => {
    setFormData({ name: '', description: '', content: '' });
    setEditingSkill(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    createSkillMutation.mutate(formData);
  };

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-5xl mx-auto px-6 py-12 space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Skills Management</h1>
            <p className="text-muted-foreground mt-2">
              Teach DocTasTic reusable procedures by creating SKILL.md files
            </p>
          </div>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="w-4 h-4" />
                New Skill
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create New Skill</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Skill Name</label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g., deploy-to-production"
                    required
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Description</label>
                  <Input
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Brief description of what this skill does"
                    required
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">SKILL.md Content</label>
                  <Textarea
                    value={formData.content}
                    onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                    placeholder="# Skill: Deploy to Production&#10;&#10;## Steps&#10;1. Run tests&#10;2. Build application&#10;3. Deploy to server"
                    className="font-mono text-xs h-64"
                    required
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={createSkillMutation.isPending}>
                    Create Skill
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Info Card */}
        <Card className="bg-primary/5 border-primary/20">
          <CardHeader>
            <CardTitle className="text-sm flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-primary" />
              What are Skills?
            </CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-secondary-foreground space-y-2">
            <p>
              Skills are reusable procedures that teach DocTasTic how to perform specific workflows consistently.
            </p>
            <p className="text-xs text-muted-foreground">
              Place skill files at <code className="px-2 py-0.5 bg-background rounded text-primary">.agents/skills/&lt;skill-name&gt;/SKILL.md</code> in your repository.
            </p>
          </CardContent>
        </Card>

        {/* Skills Grid */}
        <div className="grid md:grid-cols-2 gap-4">
          {skills.length === 0 ? (
            <div className="col-span-2 text-center py-12">
              <FileCode className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No skills created yet</p>
              <p className="text-xs text-muted-foreground mt-1">Create your first skill to get started</p>
            </div>
          ) : (
            skills.map((skill) => (
              <Card key={skill.id} className="hover:border-primary/40 transition-colors">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-base">{skill.name}</CardTitle>
                      <CardDescription className="text-xs mt-1">{skill.description}</CardDescription>
                    </div>
                    <div className="flex gap-1">
                      <Button size="icon" variant="ghost" className="h-7 w-7">
                        <Edit2 className="w-3 h-3" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-7 w-7 text-destructive"
                        onClick={() => deleteSkillMutation.mutate(skill.id)}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <pre className="bg-background rounded p-3 text-xs font-mono overflow-x-auto max-h-32">
                    {skill.content}
                  </pre>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}