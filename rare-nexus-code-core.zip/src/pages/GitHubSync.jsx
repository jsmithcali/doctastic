import React, { useState } from 'react';
import { Github, GitBranch, RefreshCw, CheckCircle2, AlertCircle, Link as LinkIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';

export default function GitHubSync() {
  const [repoUrl, setRepoUrl] = useState('');
  const [branch, setBranch] = useState('main');
  const [isConnected, setIsConnected] = useState(false);
  const [syncing, setSyncing] = useState(false);

  const handleConnect = async () => {
    if (!repoUrl) {
      toast.error('Please enter a repository URL');
      return;
    }
    
    setSyncing(true);
    // Simulate connection
    await new Promise(r => setTimeout(r, 2000));
    setIsConnected(true);
    setSyncing(false);
    toast.success('Repository connected successfully');
  };

  const handleSync = async () => {
    setSyncing(true);
    await new Promise(r => setTimeout(r, 1500));
    setSyncing(false);
    toast.success('Repository synced');
  };

  const handleDisconnect = () => {
    setIsConnected(false);
    setRepoUrl('');
    toast.info('Repository disconnected');
  };

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-4xl mx-auto px-6 py-12 space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="w-16 h-16 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center">
              <Github className="w-8 h-8 text-primary" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-foreground">GitHub Repository Sync</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Connect your GitHub repository to enable bi-directional sync between DocTasTic sessions and your codebase
          </p>
        </div>

        {/* Connection Card */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <LinkIcon className="w-5 h-5" />
              Repository Connection
            </CardTitle>
            <CardDescription>
              Connect to a GitHub repository to sync code changes in real-time
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {!isConnected ? (
              <>
                <div>
                  <label className="text-sm font-medium">Repository URL</label>
                  <Input
                    value={repoUrl}
                    onChange={(e) => setRepoUrl(e.target.value)}
                    placeholder="https://github.com/username/repository"
                    className="mt-1.5"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Branch</label>
                  <Input
                    value={branch}
                    onChange={(e) => setBranch(e.target.value)}
                    placeholder="main"
                    className="mt-1.5"
                  />
                </div>
                <Button onClick={handleConnect} disabled={syncing} className="w-full">
                  {syncing ? (
                    <>
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                      Connecting...
                    </>
                  ) : (
                    <>
                      <Github className="w-4 h-4 mr-2" />
                      Connect Repository
                    </>
                  )}
                </Button>
              </>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center gap-3 p-4 bg-primary/5 border border-primary/20 rounded-lg">
                  <CheckCircle2 className="w-5 h-5 text-primary shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">{repoUrl}</p>
                    <p className="text-xs text-muted-foreground">Branch: {branch}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button onClick={handleSync} disabled={syncing} className="flex-1">
                    {syncing ? (
                      <>
                        <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                        Syncing...
                      </>
                    ) : (
                      <>
                        <RefreshCw className="w-4 h-4 mr-2" />
                        Sync Now
                      </>
                    )}
                  </Button>
                  <Button onClick={handleDisconnect} variant="outline">
                    Disconnect
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Features */}
        <div className="grid md:grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Bi-directional Sync</CardTitle>
            </CardHeader>
            <CardContent className="text-xs text-secondary-foreground">
              Changes made by DocTasTic are automatically pushed to your repository, and external commits are pulled into active sessions.
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Branch Management</CardTitle>
            </CardHeader>
            <CardContent className="text-xs text-secondary-foreground">
              DocTasTic can create feature branches, submit pull requests, and merge changes directly from the workspace.
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Conflict Resolution</CardTitle>
            </CardHeader>
            <CardContent className="text-xs text-secondary-foreground">
              Automatic conflict detection with AI-powered merge suggestions to resolve issues intelligently.
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Commit History</CardTitle>
            </CardHeader>
            <CardContent className="text-xs text-secondary-foreground">
              Every change is tracked with detailed commit messages, making it easy to review and rollback if needed.
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}