import React from 'react';

export default function DevinLogo({ size = 48 }) {
  const s = size;
  const r1 = s * 0.125;
  const r2 = s * 0.083;
  const r3 = s * 0.0625;
  const c = s / 2;

  return (
    <svg viewBox={`0 0 ${s} ${s}`} width={s} height={s} fill="none">
      <circle cx={c} cy={c} r={r1} fill="hsl(155 100% 45%)" />
      <circle cx={c} cy={s * 0.167} r={r2} fill="hsl(155 100% 45%)" opacity="0.7" />
      <circle cx={c} cy={s * 0.833} r={r2} fill="hsl(155 100% 45%)" opacity="0.7" />
      <circle cx={s * 0.167} cy={c} r={r2} fill="hsl(155 100% 45%)" opacity="0.7" />
      <circle cx={s * 0.833} cy={c} r={r2} fill="hsl(155 100% 45%)" opacity="0.7" />
      <circle cx={s * 0.263} cy={s * 0.263} r={r3} fill="hsl(155 100% 45%)" opacity="0.5" />
      <circle cx={s * 0.737} cy={s * 0.263} r={r3} fill="hsl(155 100% 45%)" opacity="0.5" />
      <circle cx={s * 0.263} cy={s * 0.737} r={r3} fill="hsl(155 100% 45%)" opacity="0.5" />
      <circle cx={s * 0.737} cy={s * 0.737} r={r3} fill="hsl(155 100% 45%)" opacity="0.5" />
      {/* Connecting lines */}
      <line x1={c} y1={s * 0.25} x2={c} y2={s * 0.375} stroke="hsl(155 100% 45%)" strokeWidth="0.5" opacity="0.2" />
      <line x1={c} y1={s * 0.625} x2={c} y2={s * 0.75} stroke="hsl(155 100% 45%)" strokeWidth="0.5" opacity="0.2" />
      <line x1={s * 0.25} y1={c} x2={s * 0.375} y2={c} stroke="hsl(155 100% 45%)" strokeWidth="0.5" opacity="0.2" />
      <line x1={s * 0.625} y1={c} x2={s * 0.75} y2={c} stroke="hsl(155 100% 45%)" strokeWidth="0.5" opacity="0.2" />
    </svg>
  );
}