import React from 'react';
import { Monitor, FileText, GitBranch, Plus, Maximize2, MoreHorizontal } from 'lucide-react';

const workspaces = [
  { id: 'worklog', label: 'Worklog', icon: Monitor },
  { id: 'desktop', label: 'Desktop', icon: Monitor },
  { id: 'diff', label: 'Diff', icon: FileText },
];

const prs = [
  { id: 'pr3', label: 'PR #3', icon: GitBranch },
  { id: 'pr5', label: 'PR #5', icon: GitBranch },
  { id: 'pr6', label: 'PR #6', icon: GitBranch },
];

export default function WorkspaceHeader({ activeWorkspace = 'worklog' }) {
  return (
    <div className="h-9 bg-[#1a1d23] border-b border-[#2d3139] flex items-center px-2 gap-1 shrink-0">
      {/* Workspaces */}
      {workspaces.map((ws) => {
        const Icon = ws.icon;
        const isActive = ws.id === activeWorkspace;
        return (
          <button
            key={ws.id}
            className={`flex items-center gap-1.5 px-2.5 h-7 text-xs font-medium rounded transition-colors ${
              isActive
                ? 'bg-[#2d3139] text-foreground'
                : 'text-muted-foreground hover:text-foreground hover:bg-[#25282f]'
            }`}
          >
            <Icon className="w-3 h-3" />
            <span>{ws.label}</span>
          </button>
        );
      })}

      {/* Separator */}
      <div className="h-4 w-px bg-border mx-1" />

      {/* PRs */}
      {prs.map((pr) => {
        const Icon = pr.icon;
        return (
          <button
            key={pr.id}
            className="flex items-center gap-1.5 px-2.5 h-7 text-xs font-medium rounded text-primary hover:bg-[#25282f] transition-colors"
          >
            <Icon className="w-3 h-3" />
            <span>{pr.label}</span>
          </button>
        );
      })}

      {/* Actions */}
      <div className="flex-1" />
      <button className="w-7 h-7 flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-[#25282f] rounded transition-colors">
        <Plus className="w-3.5 h-3.5" />
      </button>
      <button className="w-7 h-7 flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-[#25282f] rounded transition-colors">
        <Maximize2 className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}