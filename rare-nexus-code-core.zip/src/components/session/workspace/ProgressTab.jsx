import React from 'react';
import { Terminal, FileCode, Globe, CheckCircle2, Clock, ChevronRight } from 'lucide-react';

const typeConfig = {
  shell: { icon: Terminal, label: 'Shell', color: 'text-yellow-400' },
  code: { icon: FileCode, label: 'Code edit', color: 'text-blue-400' },
  browser: { icon: Globe, label: 'Browser', color: 'text-purple-400' },
  plan: { icon: CheckCircle2, label: 'Plan update', color: 'text-primary' },
};

export default function ProgressTab({ shellHistory = [], files = [], plannerItems = [] }) {
  // Build a timeline from all activity
  const timeline = [];
  
  plannerItems.forEach((item, i) => {
    if (item.completed) {
      timeline.push({ type: 'plan', text: `Completed: ${item.text}`, time: i });
    }
  });
  
  shellHistory.forEach((entry, i) => {
    timeline.push({ type: 'shell', text: entry.command, output: entry.output, time: i + 100 });
  });
  
  files.forEach((file, i) => {
    timeline.push({ type: 'code', text: `Edited ${file.path}`, time: i + 200 });
  });

  return (
    <div className="h-full flex flex-col bg-background">
      <div className="px-4 py-3 border-b border-border space-y-2">
        <h3 className="text-xs font-semibold text-foreground">Progress - Unified Overview</h3>
        <p className="text-[10px] text-muted-foreground leading-relaxed">
          High-level overview combining all tools to provide a clear status of the task, showing completed steps, shell commands, code edits, and browser activity.
        </p>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4">
        {timeline.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <p className="text-xs text-muted-foreground">No activity yet</p>
          </div>
        ) : (
          <div className="space-y-1">
            {timeline.map((item, idx) => {
              const config = typeConfig[item.type];
              const Icon = config.icon;
              return (
                <div key={idx} className="flex items-start gap-2.5 py-1.5 px-2 rounded hover:bg-secondary/50 transition-colors group cursor-pointer">
                  <Icon className={`w-3.5 h-3.5 ${config.color} shrink-0 mt-0.5`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-foreground truncate">{item.text}</p>
                    {item.output && (
                      <p className="text-[10px] text-muted-foreground truncate mt-0.5">{item.output}</p>
                    )}
                  </div>
                  <ChevronRight className="w-3 h-3 text-muted-foreground/30 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}