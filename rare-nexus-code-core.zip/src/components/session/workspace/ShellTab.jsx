import React, { useState, useRef, useEffect } from 'react';
import { Copy, Check, Send, Terminal } from 'lucide-react';
import DebugModeToggle from '../DebugModeToggle';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export default function ShellTab({ shellHistory = [], sessionId, onUpdate, sessionStatus }) {
  const [copiedIdx, setCopiedIdx] = useState(null);
  const [debugMode, setDebugMode] = useState(false);
  const [commandInput, setCommandInput] = useState('');
  const [executing, setExecuting] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [shellHistory]);

  const handleCopy = (text, idx) => {
    navigator.clipboard.writeText(text);
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 2000);
  };

  const handleExecuteCommand = async () => {
    if (!commandInput.trim()) return;
    
    setExecuting(true);
    const newEntry = {
      command: commandInput,
      output: `Executing...`,
      timestamp: new Date().toISOString(),
    };

    // Add to shell history
    const updatedHistory = [...shellHistory, newEntry];
    
    // Simulate command execution
    await new Promise(r => setTimeout(r, 1000));
    
    updatedHistory[updatedHistory.length - 1].output = `✓ Command executed successfully`;
    
    // Update session if sessionId is provided
    if (sessionId) {
      await base44.entities.Session.update(sessionId, {
        shell_history: updatedHistory
      });
      onUpdate?.();
    }
    
    setCommandInput('');
    setExecuting(false);
    toast.success('Command executed');
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleExecuteCommand();
    }
  };

  return (
    <div className="h-full flex flex-col bg-background">
      <div className="px-4 py-3 border-b border-border space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-semibold text-foreground">Shell - Terminal Access</h3>
          <DebugModeToggle 
            debugMode={debugMode} 
            onToggle={setDebugMode}
            disabled={sessionStatus === 'paused' || sessionStatus === 'completed'}
          />
        </div>
        <p className="text-[10px] text-muted-foreground leading-relaxed">
          {debugMode 
            ? 'Debug mode active - Agent paused. Inject commands to test or debug.' 
            : 'Command-line terminal showing all actions DocTasTic takes: installing packages, compiling code, running scripts, and managing the server.'
          }
        </p>
      </div>
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 font-mono text-xs space-y-3">
        {shellHistory.length === 0 && (
          <div className="flex items-center justify-center h-full">
            <p className="text-muted-foreground text-xs">No shell activity yet</p>
          </div>
        )}
        {shellHistory.map((entry, idx) => (
          <div key={idx} className="group">
            <div className="flex items-start gap-2">
              <span className="text-primary shrink-0 select-none">$</span>
              <span className="text-foreground flex-1">{entry.command}</span>
              <button
                onClick={() => handleCopy(entry.command, idx)}
                className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-foreground"
              >
                {copiedIdx === idx ? (
                  <Check className="w-3 h-3 text-primary" />
                ) : (
                  <Copy className="w-3 h-3" />
                )}
              </button>
            </div>
            {entry.output && (
              <pre className="text-muted-foreground mt-1 ml-4 whitespace-pre-wrap">{entry.output}</pre>
            )}
          </div>
        ))}
      </div>
      
      {/* Shell input */}
      <div className="border-t border-border px-4 py-2">
        {debugMode ? (
          <div className="space-y-2">
            <div className="flex items-center gap-2 bg-yellow-500/10 border border-yellow-500/30 rounded-lg px-3 py-2">
              <Terminal className="w-3.5 h-3.5 text-yellow-500 shrink-0" />
              <input
                type="text"
                value={commandInput}
                onChange={(e) => setCommandInput(e.target.value)}
                onKeyDown={handleKeyDown}
                disabled={executing}
                placeholder="Enter command to inject..."
                className="flex-1 bg-transparent text-xs font-mono text-foreground outline-none placeholder:text-muted-foreground"
              />
              <button
                onClick={handleExecuteCommand}
                disabled={!commandInput.trim() || executing}
                className="text-yellow-500 hover:text-yellow-400 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
            <p className="text-[10px] text-yellow-500/70 px-1">
              Debug mode: Commands are injected and output will be visible to the agent when resumed
            </p>
          </div>
        ) : (
          <div className="flex items-center gap-2 bg-secondary/30 rounded-lg px-3 py-2">
            <span className="text-primary text-xs font-mono">$</span>
            <input
              type="text"
              placeholder="Read-only - Enable Debug Mode to inject commands"
              className="flex-1 bg-transparent text-xs font-mono text-muted-foreground outline-none"
              readOnly
            />
          </div>
        )}
      </div>
    </div>
  );
}