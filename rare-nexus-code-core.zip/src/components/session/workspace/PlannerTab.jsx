import React, { useState } from 'react';
import { CheckCircle2, Circle, ChevronRight, ChevronDown, Loader2 } from 'lucide-react';

function PlanItem({ item, isLast }) {
  const [expanded, setExpanded] = useState(true);
  const hasSubsteps = item.substeps && item.substeps.length > 0;

  return (
    <div className={`${!isLast ? 'mb-1' : ''}`}>
      <div
        className="flex items-start gap-2 px-3 py-2 rounded-md hover:bg-secondary/50 transition-colors cursor-pointer group"
        onClick={() => hasSubsteps && setExpanded(!expanded)}
      >
        {item.completed ? (
          <CheckCircle2 className="w-4 h-4 text-primary shrink-0 mt-0.5" />
        ) : item.substeps?.some(s => s.completed) ? (
          <Loader2 className="w-4 h-4 text-primary/70 shrink-0 mt-0.5 animate-spin" />
        ) : (
          <Circle className="w-4 h-4 text-muted-foreground/40 shrink-0 mt-0.5" />
        )}
        <span className={`text-xs flex-1 ${item.completed ? 'text-muted-foreground line-through' : 'text-foreground'}`}>
          {item.text}
        </span>
        {hasSubsteps && (
          <span className="text-muted-foreground">
            {expanded ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
          </span>
        )}
      </div>
      
      {hasSubsteps && expanded && (
        <div className="ml-6 border-l border-border pl-2 space-y-0.5">
          {item.substeps.map((sub, idx) => (
            <div key={idx} className="flex items-center gap-2 px-2 py-1">
              {sub.completed ? (
                <CheckCircle2 className="w-3 h-3 text-primary shrink-0" />
              ) : (
                <Circle className="w-3 h-3 text-muted-foreground/30 shrink-0" />
              )}
              <span className={`text-[11px] ${sub.completed ? 'text-muted-foreground line-through' : 'text-secondary-foreground'}`}>
                {sub.text}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function PlannerTab({ plannerItems = [] }) {
  const total = plannerItems.length;
  const completed = plannerItems.filter(i => i.completed).length;

  return (
    <div className="h-full flex flex-col bg-background">
      <div className="px-4 py-3 border-b border-border space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-semibold text-foreground">Planner - The Thought Process</h3>
          {total > 0 && (
            <span className="text-[10px] text-muted-foreground">
              {completed}/{total} completed
            </span>
          )}
        </div>
        <p className="text-[10px] text-muted-foreground leading-relaxed">
          Displays the step-by-step plan DocTasTic has created to solve your prompt. Each step breaks down high-level requests into actionable engineering tasks.
        </p>
      </div>
      
      <div className="flex-1 overflow-y-auto p-2">
        {plannerItems.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <p className="text-xs text-muted-foreground">No plan yet</p>
          </div>
        ) : (
          <div className="space-y-0.5">
            {plannerItems.map((item, idx) => (
              <PlanItem key={idx} item={item} isLast={idx === plannerItems.length - 1} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}