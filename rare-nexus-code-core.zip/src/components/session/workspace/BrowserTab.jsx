import React, { useState } from 'react';
import { Globe, RefreshCw, ChevronLeft, ChevronRight, Lock } from 'lucide-react';

export default function BrowserTab({ browserUrl = '' }) {
  const [url, setUrl] = useState(browserUrl || 'about:blank');

  return (
    <div className="h-full flex flex-col bg-background">
      <div className="px-4 py-3 border-b border-border space-y-2">
        <h3 className="text-xs font-semibold text-foreground">Browser - Testing and Research</h3>
        <p className="text-[10px] text-muted-foreground leading-relaxed">
          Built-in web browser for viewing applications being built, browsing documentation, and verifying UI changes work as expected.
        </p>
      </div>
      {/* Browser toolbar */}
      <div className="flex items-center gap-2 px-3 py-2 border-b border-border bg-card">
        <div className="flex items-center gap-1">
          <button className="p-1 text-muted-foreground hover:text-foreground transition-colors rounded">
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
          <button className="p-1 text-muted-foreground hover:text-foreground transition-colors rounded">
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
          <button className="p-1 text-muted-foreground hover:text-foreground transition-colors rounded">
            <RefreshCw className="w-3 h-3" />
          </button>
        </div>
        <div className="flex-1 flex items-center gap-1.5 bg-secondary rounded-md px-2.5 py-1">
          <Lock className="w-3 h-3 text-primary shrink-0" />
          <span className="text-xs text-muted-foreground truncate">{url}</span>
        </div>
      </div>

      {/* Browser viewport */}
      <div className="flex-1 flex items-center justify-center">
        {browserUrl ? (
          <div className="text-center">
            <Globe className="w-8 h-8 text-muted-foreground/30 mx-auto mb-3" />
            <p className="text-xs text-muted-foreground">Preview: {browserUrl}</p>
            <div className="mt-4 rounded-lg border border-border bg-card p-6 mx-8">
              <div className="space-y-3">
                <div className="h-3 bg-secondary rounded w-3/4 mx-auto" />
                <div className="h-3 bg-secondary rounded w-1/2 mx-auto" />
                <div className="h-20 bg-secondary rounded w-full" />
                <div className="flex gap-2 justify-center">
                  <div className="h-8 bg-primary/20 rounded w-20" />
                  <div className="h-8 bg-secondary rounded w-20" />
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center">
            <Globe className="w-8 h-8 text-muted-foreground/20 mx-auto mb-3" />
            <p className="text-xs text-muted-foreground">No browser activity yet</p>
          </div>
        )}
      </div>
    </div>
  );
}