import React, { useState } from 'react';
import { File, Folder, ChevronRight, ChevronDown, FileCode, FileJson, FileText } from 'lucide-react';

const fileIcons = {
  js: FileCode,
  jsx: FileCode,
  ts: FileCode,
  tsx: FileCode,
  json: FileJson,
  md: FileText,
};

function getIcon(name) {
  const ext = name.split('.').pop();
  return fileIcons[ext] || File;
}

export default function CodeEditorTab({ files = [] }) {
  const [selectedFile, setSelectedFile] = useState(files[0] || null);
  const [expandedFolders, setExpandedFolders] = useState(new Set(['src']));

  // Group files by directory
  const fileTree = {};
  files.forEach((file) => {
    const parts = file.path.split('/');
    if (parts.length > 1) {
      const dir = parts.slice(0, -1).join('/');
      if (!fileTree[dir]) fileTree[dir] = [];
      fileTree[dir].push(file);
    } else {
      if (!fileTree['root']) fileTree['root'] = [];
      fileTree['root'].push(file);
    }
  });

  const toggleFolder = (folder) => {
    setExpandedFolders((prev) => {
      const next = new Set(prev);
      if (next.has(folder)) next.delete(folder);
      else next.add(folder);
      return next;
    });
  };

  return (
    <div className="h-full flex flex-col bg-background">
      <div className="px-4 py-3 border-b border-border space-y-2">
        <h3 className="text-xs font-semibold text-foreground">Editor - Code Development</h3>
        <p className="text-[10px] text-muted-foreground leading-relaxed">
          Integrated code editor for creating, editing, and managing files. Watch DocTasTic write code in real-time and make your own edits.
        </p>
      </div>
      <div className="flex-1 flex bg-background min-h-0">
      {/* File tree sidebar */}
      <div className="w-48 border-r border-border overflow-y-auto shrink-0">
        <div className="px-3 py-2">
          <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Explorer</p>
        </div>
        {files.length === 0 ? (
          <p className="text-xs text-muted-foreground px-3 py-2">No files yet</p>
        ) : (
          <div className="space-y-0.5 px-1">
            {Object.entries(fileTree).map(([dir, dirFiles]) => (
              <div key={dir}>
                {dir !== 'root' && (
                  <button
                    onClick={() => toggleFolder(dir)}
                    className="flex items-center gap-1 w-full px-2 py-1 text-xs text-muted-foreground hover:text-foreground hover:bg-secondary rounded transition-colors"
                  >
                    {expandedFolders.has(dir) ? (
                      <ChevronDown className="w-3 h-3 shrink-0" />
                    ) : (
                      <ChevronRight className="w-3 h-3 shrink-0" />
                    )}
                    <Folder className="w-3 h-3 text-primary/60 shrink-0" />
                    <span className="truncate">{dir}</span>
                  </button>
                )}
                {(dir === 'root' || expandedFolders.has(dir)) && dirFiles.map((file) => {
                  const Icon = getIcon(file.name);
                  return (
                    <button
                      key={file.path}
                      onClick={() => setSelectedFile(file)}
                      className={`flex items-center gap-1.5 w-full px-2 py-1 text-xs rounded transition-colors ${
                        dir !== 'root' ? 'ml-3' : ''
                      } ${
                        selectedFile?.path === file.path
                          ? 'bg-secondary text-foreground'
                          : 'text-muted-foreground hover:text-foreground hover:bg-secondary/50'
                      }`}
                    >
                      <Icon className="w-3 h-3 shrink-0" />
                      <span className="truncate">{file.name}</span>
                    </button>
                  );
                })}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Code area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {selectedFile ? (
          <>
            {/* File tab bar */}
            <div className="flex items-center border-b border-border bg-card">
              <div className="flex items-center gap-1.5 px-3 py-1.5 border-r border-border bg-secondary text-xs">
                <span className="text-foreground">{selectedFile.name}</span>
              </div>
            </div>
            {/* Code content */}
            <div className="flex-1 overflow-auto p-4">
              <pre className="text-xs font-mono leading-5">
                {selectedFile.content.split('\n').map((line, i) => (
                  <div key={i} className="flex">
                    <span className="inline-block w-8 text-right mr-4 text-muted-foreground/50 select-none shrink-0">
                      {i + 1}
                    </span>
                    <span className="text-foreground">{line || ' '}</span>
                  </div>
                ))}
              </pre>
            </div>
          </>
        ) : (
          <div className="flex items-center justify-center h-full">
            <p className="text-muted-foreground text-xs">No file selected</p>
          </div>
        )}
      </div>
      </div>
    </div>
  );
}