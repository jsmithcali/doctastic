import React, { useState } from 'react';
import { Terminal, Code2, Globe, ListChecks, BarChart3 } from 'lucide-react';
import WorkspaceHeader from './WorkspaceHeader';
import ShellTab from './workspace/ShellTab';
import CodeEditorTab from './workspace/CodeEditorTab';
import BrowserTab from './workspace/BrowserTab';
import PlannerTab from './workspace/PlannerTab';
import ProgressTab from './workspace/ProgressTab';

const tabs = [
  { id: 'planner', label: 'Planner', icon: ListChecks, description: 'The Thought Process' },
  { id: 'code', label: 'Editor', icon: Code2, description: 'Code Development' },
  { id: 'shell', label: 'Shell', icon: Terminal, description: 'Terminal Access' },
  { id: 'browser', label: 'Browser', icon: Globe, description: 'Testing and Research' },
  { id: 'progress', label: 'Progress', icon: BarChart3, description: 'Unified Overview' },
];

export default function WorkspacePanel({ session }) {
  const [activeTab, setActiveTab] = useState('planner');

  return (
    <div className="h-full flex flex-col bg-card border-l border-border">
      {/* Workspace Header */}
      <WorkspaceHeader />
      
      {/* Tab bar */}
      <div className="flex items-center border-b border-border bg-[#1a1d23] px-2 shrink-0">
        <div className="flex items-center gap-0.5 py-1">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded transition-all ${
                  isActive
                    ? 'text-foreground bg-[#2d3139]'
                    : 'text-muted-foreground hover:text-foreground hover:bg-[#25282f]'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Tab content */}
      <div className="flex-1 overflow-hidden">
        {activeTab === 'progress' && (
          <ProgressTab
            shellHistory={session?.shell_history || []}
            files={session?.files || []}
            plannerItems={session?.planner_items || []}
          />
        )}
        {activeTab === 'shell' && (
          <ShellTab 
            shellHistory={session?.shell_history || []} 
            sessionId={session?.id}
            sessionStatus={session?.status}
            onUpdate={() => {
              // Trigger session refresh
            }}
          />
        )}
        {activeTab === 'code' && <CodeEditorTab files={session?.files || []} />}
        {activeTab === 'browser' && <BrowserTab browserUrl={session?.browser_url} />}
        {activeTab === 'planner' && <PlannerTab plannerItems={session?.planner_items || []} />}
      </div>
    </div>
  );
}