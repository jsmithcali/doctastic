import React, { useState, useRef, useEffect } from 'react';
import { Send, Plus, Paperclip, Loader2, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ChatMessage from './ChatMessage';
import SessionControls from './SessionControls';

export default function ChatPanel({ messages, onSendMessage, isProcessing, sessionStatus, session, onSessionUpdate }) {
  const [input, setInput] = useState('');
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!input.trim() || isProcessing) return;
    onSendMessage(input.trim());
    setInput('');
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header with controls */}
      <div className="border-b border-border px-4 py-2 bg-card">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Save className="w-3.5 h-3.5 text-primary" />
            <span className="text-[10px] text-muted-foreground">Auto-saved</span>
          </div>
          <SessionControls session={session} onUpdate={onSessionUpdate} />
        </div>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-4 space-y-1">
        {messages.length === 0 && (
          <div className="flex items-center justify-center h-full">
            <p className="text-muted-foreground text-sm">Start a conversation with DocTasTic</p>
          </div>
        )}
        {messages.map((msg, i) => (
          <ChatMessage key={msg.id || i} message={msg} />
        ))}
        {isProcessing && (
          <div className="flex items-center gap-2 px-3 py-2">
            <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center">
              <Loader2 className="w-3 h-3 text-primary animate-spin" />
            </div>
            <span className="text-xs text-muted-foreground">DocTasTic is thinking...</span>
          </div>
        )}
      </div>

      {/* Input */}
      <div className="border-t border-border p-3">
        {sessionStatus === 'running' && (
          <div className="flex items-center gap-1.5 mb-2">
            <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
            <span className="text-[10px] text-primary font-medium">DocTasTic is working</span>
          </div>
        )}
        <form onSubmit={handleSubmit} className="relative">
          <div className="flex items-end gap-2 bg-secondary rounded-xl px-3 py-2 border border-border focus-within:border-primary/40 transition-colors">
            <button type="button" className="text-muted-foreground hover:text-foreground transition-colors shrink-0 pb-0.5">
              <Plus className="w-4 h-4" />
            </button>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSubmit(e);
                }
              }}
              placeholder="Message DocTasTic – this won't interrupt its work"
              className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground resize-none outline-none min-h-[20px] max-h-[120px]"
              rows={1}
            />
            <button
              type="submit"
              disabled={!input.trim() || isProcessing}
              className="text-primary hover:text-primary/80 disabled:text-muted-foreground disabled:opacity-50 transition-colors shrink-0 pb-0.5"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}