import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Plus, MessageSquare, ChevronLeft, ChevronRight, Loader2, CheckCircle2, AlertCircle, PauseCircle, GitBranch, MoreVertical } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import BranchSessionDialog from './BranchSessionDialog';

const statusConfig = {
  running: { icon: Loader2, color: 'text-primary', spin: true },
  completed: { icon: CheckCircle2, color: 'text-primary' },
  paused: { icon: PauseCircle, color: 'text-yellow-400' },
  failed: { icon: AlertCircle, color: 'text-destructive' },
};

export default function SessionSidebar({ currentSessionId }) {
  const [collapsed, setCollapsed] = useState(false);
  const [branchDialogOpen, setBranchDialogOpen] = useState(false);
  const [selectedSession, setSelectedSession] = useState(null);
  const navigate = useNavigate();

  const { data: sessions = [] } = useQuery({
    queryKey: ['sessions'],
    queryFn: () => base44.entities.Session.list('-created_date', 50),
  });

  const handleNewSession = () => {
    navigate('/');
  };

  const handleBranchSession = (session) => {
    setSelectedSession(session);
    setBranchDialogOpen(true);
  };

  return (
    <>
      <BranchSessionDialog 
        session={selectedSession} 
        open={branchDialogOpen} 
        onOpenChange={setBranchDialogOpen} 
      />
      <div className={`${collapsed ? 'w-12' : 'w-56'} shrink-0 border-r border-border bg-sidebar flex flex-col transition-all duration-200`}>
      {/* Header */}
      <div className={`flex items-center ${collapsed ? 'justify-center' : 'justify-between'} p-2 border-b border-sidebar-border`}>
        {!collapsed && (
          <span className="text-[10px] font-semibold text-sidebar-foreground uppercase tracking-wider pl-1">Sessions</span>
        )}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="p-1 text-sidebar-foreground hover:text-foreground transition-colors rounded"
        >
          {collapsed ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronLeft className="w-3.5 h-3.5" />}
        </button>
      </div>

      {/* New session button */}
      <div className="p-2">
        <button
          onClick={handleNewSession}
          className={`flex items-center gap-2 w-full ${collapsed ? 'justify-center p-1.5' : 'px-2 py-1.5'} rounded-md text-xs font-medium text-primary hover:bg-sidebar-accent transition-colors`}
        >
          <Plus className="w-3.5 h-3.5 shrink-0" />
          {!collapsed && <span>New session</span>}
        </button>
      </div>

      {/* Session list */}
      <div className="flex-1 overflow-y-auto px-1.5 space-y-0.5">
        {sessions.map((session) => {
          const isActive = session.id === currentSessionId;
          const status = statusConfig[session.status] || statusConfig.running;
          const StatusIcon = status.icon;
          
          return (
            <div key={session.id} className="flex items-center gap-1 w-full group">
              <Link
                to={`/session/${session.id}`}
                className={`flex items-center gap-2 flex-1 rounded-md transition-colors ${
                  collapsed ? 'justify-center p-2' : 'px-2 py-1.5'
                } ${
                  isActive
                    ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                    : 'text-sidebar-foreground hover:bg-sidebar-accent/50'
                }`}
              >
                <StatusIcon className={`w-3 h-3 ${status.color} shrink-0 ${status.spin ? 'animate-spin' : ''}`} />
                {!collapsed && (
                  <span className="text-xs truncate flex-1">{session.title}</span>
                )}
              </Link>
              {!collapsed && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button className="opacity-0 group-hover:opacity-100 p-1 hover:bg-sidebar-accent rounded transition-opacity">
                      <MoreVertical className="w-3 h-3 text-sidebar-foreground" />
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => handleBranchSession(session)}>
                      <GitBranch className="w-3 h-3 mr-2" />
                      Branch Session
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>
          );
        })}
      </div>
      </div>
    </>
  );
}