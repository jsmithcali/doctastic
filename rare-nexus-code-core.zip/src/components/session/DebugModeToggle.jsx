import React from 'react';
import { Bug, Play } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

export default function DebugModeToggle({ debugMode, onToggle, disabled }) {
  const handleToggle = () => {
    onToggle(!debugMode);
    toast.info(debugMode ? 'Debug mode disabled - agent resumed' : 'Debug mode enabled - agent paused');
  };

  return (
    <Button
      size="sm"
      variant={debugMode ? "default" : "outline"}
      onClick={handleToggle}
      disabled={disabled}
      className={`h-7 text-xs gap-1.5 ${debugMode ? 'bg-yellow-600 hover:bg-yellow-700' : ''}`}
    >
      {debugMode ? <Play className="w-3 h-3" /> : <Bug className="w-3 h-3" />}
      {debugMode ? 'Resume Agent' : 'Debug Mode'}
    </Button>
  );
}