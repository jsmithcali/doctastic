import React, { useState } from 'react';
import { GitBranch, Copy } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

export default function BranchSessionDialog({ session, open, onOpenChange }) {
  const [branchName, setBranchName] = useState(`${session?.title || 'Session'} - Branch`);
  const [branching, setBranching] = useState(false);
  const navigate = useNavigate();

  const handleBranch = async () => {
    if (!session) return;
    
    setBranching(true);
    
    // Create a new session with copied state
    const branchedSession = await base44.entities.Session.create({
      title: branchName,
      status: 'running',
      planner_items: session.planner_items || [],
      shell_history: session.shell_history || [],
      files: session.files || [],
      browser_url: session.browser_url || '',
    });

    // Copy all messages from original session
    const messages = await base44.entities.ChatMessage.filter({ 
      session_id: session.id 
    }, 'created_date');
    
    for (const msg of messages) {
      await base44.entities.ChatMessage.create({
        session_id: branchedSession.id,
        role: msg.role,
        content: msg.content,
        message_type: msg.message_type,
      });
    }
    
    // Add a system message indicating this is a branch
    await base44.entities.ChatMessage.create({
      session_id: branchedSession.id,
      role: 'assistant',
      content: `🔀 **Branched from:** ${session.title}\n\nThis session is a copy of the original. You can now experiment with different approaches without affecting the original session.`,
      message_type: 'status',
    });

    setBranching(false);
    onOpenChange(false);
    toast.success('Session branched successfully');
    navigate(`/session/${branchedSession.id}`);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <GitBranch className="w-5 h-5 text-primary" />
            Branch Session
          </DialogTitle>
          <DialogDescription>
            Create a copy of this session to experiment with different approaches without affecting the original.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 pt-4">
          <div>
            <label className="text-sm font-medium">Branch Name</label>
            <Input
              value={branchName}
              onChange={(e) => setBranchName(e.target.value)}
              placeholder="Enter branch name..."
              className="mt-1.5"
            />
          </div>
          <div className="bg-muted/50 rounded-lg p-3 text-xs text-muted-foreground space-y-1">
            <p className="flex items-center gap-2">
              <Copy className="w-3 h-3" />
              Copies: planner items, shell history, files, and chat messages
            </p>
            <p>• Both sessions will run independently</p>
            <p>• Changes in one won't affect the other</p>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button onClick={handleBranch} disabled={branching || !branchName.trim()}>
              {branching ? 'Branching...' : 'Create Branch'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}