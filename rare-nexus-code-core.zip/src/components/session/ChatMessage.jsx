import React from 'react';
import ReactMarkdown from 'react-markdown';
import { Bot, User, Terminal, FileCode, CheckSquare } from 'lucide-react';

const typeIcons = {
  shell: Terminal,
  code: FileCode,
  plan_update: CheckSquare,
};

export default function ChatMessage({ message }) {
  const isUser = message.role === 'user';
  const TypeIcon = typeIcons[message.message_type];

  return (
    <div className={`flex gap-3 py-3 ${isUser ? '' : ''}`}>
      <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 mt-0.5 ${
        isUser ? 'bg-secondary' : 'bg-primary/15'
      }`}>
        {isUser ? (
          <User className="w-3 h-3 text-muted-foreground" />
        ) : (
          <Bot className="w-3 h-3 text-primary" />
        )}
      </div>
      
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs font-semibold text-foreground">
            {isUser ? 'You' : 'DocTasTic'}
          </span>
          {TypeIcon && message.message_type !== 'text' && (
            <span className="flex items-center gap-1 text-[10px] text-muted-foreground bg-secondary px-1.5 py-0.5 rounded">
              <TypeIcon className="w-2.5 h-2.5" />
              {message.message_type.replace('_', ' ')}
            </span>
          )}
        </div>
        
        {message.message_type === 'code' ? (
          <pre className="bg-background rounded-lg p-3 text-xs font-mono overflow-x-auto border border-border">
            <code className="text-foreground">{message.content}</code>
          </pre>
        ) : message.message_type === 'shell' ? (
          <div className="bg-background rounded-lg p-3 font-mono text-xs border border-border">
            <div className="flex items-center gap-2 text-primary mb-1">
              <span className="text-muted-foreground">$</span>
              <span>{message.content}</span>
            </div>
          </div>
        ) : (
          <div className="text-sm text-secondary-foreground leading-relaxed">
            <ReactMarkdown
              components={{
                p: ({ children }) => <p className="mb-2 last:mb-0">{children}</p>,
                code: ({ inline, children }) => inline ? (
                  <code className="px-1 py-0.5 bg-background rounded text-xs font-mono text-primary">{children}</code>
                ) : (
                  <pre className="bg-background rounded-lg p-3 text-xs font-mono overflow-x-auto border border-border my-2">
                    <code>{children}</code>
                  </pre>
                ),
                ul: ({ children }) => <ul className="list-disc ml-4 mb-2 space-y-1">{children}</ul>,
                ol: ({ children }) => <ol className="list-decimal ml-4 mb-2 space-y-1">{children}</ol>,
                li: ({ children }) => <li className="text-sm">{children}</li>,
                strong: ({ children }) => <strong className="font-semibold text-foreground">{children}</strong>,
              }}
            >
              {message.content}
            </ReactMarkdown>
          </div>
        )}
      </div>
    </div>
  );
}