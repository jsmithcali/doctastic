import React from 'react';
import { Pause, Play, Square, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export default function SessionControls({ session, onUpdate }) {
  const handlePause = async () => {
    await base44.entities.Session.update(session.id, { status: 'paused' });
    onUpdate();
    toast.success('Session paused - your progress has been saved');
  };

  const handleResume = async () => {
    await base44.entities.Session.update(session.id, { status: 'running' });
    onUpdate();
    toast.success('Session resumed');
  };

  const handleStop = async () => {
    await base44.entities.Session.update(session.id, { status: 'completed' });
    onUpdate();
    toast.info('Session stopped');
  };

  const handleReset = async () => {
    await base44.entities.Session.update(session.id, {
      status: 'running',
      planner_items: session.planner_items.map(item => ({
        ...item,
        completed: false,
        substeps: (item.substeps || []).map(s => ({ ...s, completed: false }))
      }))
    });
    onUpdate();
    toast.info('Session reset - all tasks marked as incomplete');
  };

  const status = session?.status || 'running';

  return (
    <div className="flex items-center gap-1.5">
      {status === 'running' && (
        <Button
          size="sm"
          variant="outline"
          onClick={handlePause}
          className="h-7 text-xs gap-1.5"
        >
          <Pause className="w-3 h-3" />
          Pause
        </Button>
      )}
      
      {status === 'paused' && (
        <Button
          size="sm"
          variant="outline"
          onClick={handleResume}
          className="h-7 text-xs gap-1.5 border-primary text-primary hover:bg-primary/10"
        >
          <Play className="w-3 h-3" />
          Resume
        </Button>
      )}

      {(status === 'running' || status === 'paused') && (
        <>
          <Button
            size="sm"
            variant="outline"
            onClick={handleStop}
            className="h-7 text-xs gap-1.5"
          >
            <Square className="w-3 h-3" />
            Stop
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={handleReset}
            className="h-7 text-xs gap-1.5"
          >
            <RotateCcw className="w-3 h-3" />
            Reset
          </Button>
        </>
      )}

      {status === 'completed' && (
        <Button
          size="sm"
          variant="outline"
          onClick={handleReset}
          className="h-7 text-xs gap-1.5"
        >
          <RotateCcw className="w-3 h-3" />
          Restart
        </Button>
      )}
    </div>
  );
}