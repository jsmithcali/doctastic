import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ExternalLink } from 'lucide-react';

const DevinLogo = () => (
  <svg viewBox="0 0 24 24" className="w-6 h-6" fill="none">
    <circle cx="12" cy="12" r="3" fill="hsl(155 100% 45%)" />
    <circle cx="12" cy="4" r="2" fill="hsl(155 100% 45%)" opacity="0.7" />
    <circle cx="12" cy="20" r="2" fill="hsl(155 100% 45%)" opacity="0.7" />
    <circle cx="4" cy="12" r="2" fill="hsl(155 100% 45%)" opacity="0.7" />
    <circle cx="20" cy="12" r="2" fill="hsl(155 100% 45%)" opacity="0.7" />
    <circle cx="6.3" cy="6.3" r="1.5" fill="hsl(155 100% 45%)" opacity="0.5" />
    <circle cx="17.7" cy="6.3" r="1.5" fill="hsl(155 100% 45%)" opacity="0.5" />
    <circle cx="6.3" cy="17.7" r="1.5" fill="hsl(155 100% 45%)" opacity="0.5" />
    <circle cx="17.7" cy="17.7" r="1.5" fill="hsl(155 100% 45%)" opacity="0.5" />
  </svg>
);

export default function TopNav() {
  const location = useLocation();
  
  const navLinks = [
    { label: 'Home', path: '/' },
    { label: 'Wiki', path: '/wiki' },
    { label: 'Review', path: '/review' },
    { label: 'Skills', path: '/skills' },
    { label: 'GitHub', path: '/github' },
    { label: 'Self-Hosting', path: '/self-hosting' },
    { label: 'Docs', path: '/docs' },
  ];

  return (
    <header className="h-12 border-b border-border bg-background flex items-center justify-between px-4 shrink-0 z-50">
      <div className="flex items-center gap-6">
        <Link to="/" className="flex items-center gap-2.5">
          <DevinLogo />
          <span className="text-foreground font-semibold text-sm tracking-tight">DocTasTic</span>
        </Link>
        
        <nav className="flex items-center gap-1">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                location.pathname === link.path
                  ? 'text-foreground bg-secondary'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {link.label}
            </Link>
          ))}

        </nav>
      </div>
    </header>
  );
}